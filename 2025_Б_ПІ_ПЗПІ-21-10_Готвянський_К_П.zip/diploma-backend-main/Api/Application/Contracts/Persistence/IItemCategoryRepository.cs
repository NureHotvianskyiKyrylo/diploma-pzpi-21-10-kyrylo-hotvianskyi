﻿using Api.Domain;

namespace Api.Application.Contracts.Persistence;

public interface IItemCategoryRepository : IGenericRepository<ItemCategory>
{
    
}