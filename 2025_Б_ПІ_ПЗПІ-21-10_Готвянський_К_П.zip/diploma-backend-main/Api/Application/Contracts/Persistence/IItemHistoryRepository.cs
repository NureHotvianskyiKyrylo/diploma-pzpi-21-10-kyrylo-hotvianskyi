﻿using Api.Domain;

namespace Api.Application.Contracts.Persistence;

public interface IItemHistoryRepository : IGenericRepository<ItemHistory>
{
    
}