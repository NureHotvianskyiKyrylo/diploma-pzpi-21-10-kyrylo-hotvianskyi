﻿using Api.Domain;

namespace Api.Application.Contracts.Persistence;

public interface IItemRepository : IGenericRepository<Item>
{
    
}