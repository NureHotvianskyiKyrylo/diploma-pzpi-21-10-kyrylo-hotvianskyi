﻿using Api.Domain;

namespace Api.Application.Contracts.Persistence;

public interface IAssignmentRepository : IGenericRepository<Assignment>
{
    
}