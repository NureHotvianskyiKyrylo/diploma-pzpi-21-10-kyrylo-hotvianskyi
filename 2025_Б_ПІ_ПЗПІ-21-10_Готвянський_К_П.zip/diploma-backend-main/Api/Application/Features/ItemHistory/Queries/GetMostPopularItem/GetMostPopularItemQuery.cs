﻿using MediatR;

namespace Api.Application.Features.ItemHistory.Queries.GetMostPopularItem;

public class GetMostPopularItemQuery : IRequest<GetMostPopularItemResponse>
{
    
}