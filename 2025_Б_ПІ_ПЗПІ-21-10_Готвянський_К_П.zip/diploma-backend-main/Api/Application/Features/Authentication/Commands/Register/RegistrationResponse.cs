﻿namespace Api.Application.Features.Authentication.Commands.Register;

public class RegistrationResponse
{
    public string UserId { get; set; } = null!;
}