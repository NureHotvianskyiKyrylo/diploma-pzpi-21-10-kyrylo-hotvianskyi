﻿namespace Api.Application.Features.AssignmentToUserStatus.Common;

public class AssignmentToUserStatusDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}