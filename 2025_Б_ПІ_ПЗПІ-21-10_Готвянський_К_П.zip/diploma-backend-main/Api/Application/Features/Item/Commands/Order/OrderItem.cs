﻿namespace Api.Application.Features.Item.Commands.Order;

public class OrderItem
{
    public string Name { get; set; }
    public int Quantity { get; set; }
}