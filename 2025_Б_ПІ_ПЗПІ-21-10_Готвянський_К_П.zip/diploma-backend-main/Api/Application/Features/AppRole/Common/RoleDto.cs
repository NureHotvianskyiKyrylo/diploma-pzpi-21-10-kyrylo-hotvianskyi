﻿namespace Api.Application.Features.AppRole.Common;

public class RoleDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}