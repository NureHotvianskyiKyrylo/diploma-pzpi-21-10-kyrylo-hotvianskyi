﻿namespace Api.Application.Features.ItemCategory.Common;

public class ItemCategoryDto
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}