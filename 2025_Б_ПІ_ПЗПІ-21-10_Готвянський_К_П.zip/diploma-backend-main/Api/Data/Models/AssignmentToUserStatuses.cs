﻿namespace Api.Data.Models;

public enum AssignmentToUserStatuses
{
    NotAccepted, 
    InProgress, 
    Completed, 
    Approved, 
    Rejected
}