﻿namespace Api.Data.Models;

public enum Roles
{
    Manager,
    Administrator,
    Technician,
    Housemaid,
    InventoryManager
}